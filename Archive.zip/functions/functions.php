<?php

include("fnc_login.php");
include("fnc_parse_json.php");
include("fnc_showHomePage.php");

?>